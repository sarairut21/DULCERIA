create database dulceria;
use dulceria;
create table datos (
id_dts int auto_increment primary key,
dts_usuario varchar (50),
dts_contraseña varchar (50));

create table admin (
id_adm int auto_increment primary key,
adm_nombre varchar (50),
adm_correo varchar (50),
adm_celular varchar (50));

create table productos (
id_prd int auto_increment primary key,
prd_nombre varchar (50),
prd_precio varchar (50),
prd_marca varchar (50));

create table ticket (
id_tic int auto_increment primary key,
tic_producto  varchar (50),
tic_venta varchar (50),
tic_direccion varchar (50));


